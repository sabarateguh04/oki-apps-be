# CHANGELOG FIX 2 — Perbaikan Lanjutan

## 1. Bug kritis: upload bukti biaya/kebutuhan "cuma yang pertama ke-save"

**Akar masalahnya:** tiap kali 1 baris (biaya/kebutuhan) berhasil ditandai
selesai, halaman manggil `loadOrder()` yang nge-render ULANG SELURUH
halaman lewat `innerHTML`. Kalau kamu sempat pilih file di beberapa baris
sekaligus SEBELUM klik "Tandai Selesai" satu-satu, begitu baris pertama
berhasil disubmit → seluruh halaman di-render ulang → pilihan file di
baris LAIN yang belum sempat disubmit ikut ke-reset ke kosong. Ditambah
lagi backend-nya dulu gak MEWAJIBKAN file, jadi baris berikutnya tetap
"berhasil" ditandai selesai walau filenya kosong (makanya kelihatan
"ke-save" padahal buktinya nggak ada).

**Perbaikan:**
- **Backend** (`routes/order.route.js`): endpoint `/:id/biaya/:biayaId/bayar`
  dan `/:id/kebutuhan/:kebutuhanId/dibeli` sekarang **menolak** request
  tanpa file (`400 Bad Request`, pesan jelas), gak lagi diam-diam sukses
  tanpa bukti.
- **Frontend** (`public/order-detail.html`): submit 1 baris biaya/kebutuhan
  sekarang **cuma refresh baris itu sendiri** (`refreshRowOnly()`), TIDAK
  lagi render ulang seluruh halaman — jadi file yang lagi dipilih di baris
  lain aman, gak ke-reset. Ada juga validasi instan di sisi client (toast
  langsung kalau lupa pilih file, gak perlu nunggu round-trip ke server).

## 2. Rekening tujuan transfer teknisi belum jelas di halaman Finance

Sebelumnya info rekening cuma nongol di panel "Teknisi" yang terpisah dari
baris biaya "Jasa Teknisi" yang lagi diproses. Sekarang info rekening
(bank, no. rekening, atas nama) ditampilkan **langsung di baris "Jasa"**
pada Rincian Biaya, persis di sebelah tombol "Tandai Sudah Ditransfer" —
juga sudah muncul untuk teknisi yang sudah **ASSIGNED** (sebelumnya cuma
muncul untuk yang statusnya ACCEPTED, ilang begitu naik status jadi
ASSIGNED).

## 3. Tutup Tiket sekarang dikunci dengan pesan jelas (bukan cuma ditolak diam-diam)

Backend sebenarnya sudah benar menolak `/close` kalau masih ada biaya
`PENDING` — tapi tombolnya tetap muncul & bisa diklik, jadi admin baru tau
gagalnya setelah klik. Sekarang tombol "Tutup Tiket" **otomatis
disembunyikan** dan diganti pesan terkunci ("Masih ada N biaya yang belum
ditransfer Finance") kalau syaratnya belum lengkap — sama persis pola yang
dipakai di tombol Assign.

## 4. Halaman Teknisi: detail tugas lengkap + bukti pekerjaan (baru)

Halaman baru **`task-detail.html`** — diakses dari "Order Aktif Saya" atau
klik baris di "Riwayat Tugas" di Profile teknisi:
- Info lengkap tugas (lokasi, jadwal, deskripsi) + peta.
- **Lampiran dari Admin** (dokumen pendukung yang di-upload waktu order dibuat).
- **Bukti Pekerjaan** — teknisi sekarang bisa **upload foto/dokumen bukti
  hasil kerjanya sendiri** (fitur baru), bisa nambah kapan saja selama
  status ON_THE_WAY/IN_PROGRESS/DONE, dan bisa lebih dari 1 file/kali.
- **Pembayaran Jasa Saya** — teknisi bisa lihat status & bukti transfer
  jasa buat dirinya sendiri (read-only), TANPA bisa lihat rincian biaya
  lain (material dll) atau rekening teknisi lain yang mungkin satu order
  (data itu di-redact khusus untuk role teknisi di endpoint `GET /:id`).
- Tombol update status (Menuju Lokasi/Dikerjakan/Selesai) juga ada di sini,
  gak cuma di halaman Profile.

### Perubahan skema pendukung (lihat `migration_v2.sql` bagian **MIGRATION V5**)
- `oki_order_files.kategori` nambah nilai baru `PEKERJAAN`.
- `oki_order_files` nambah kolom `uploaded_by_technician_id` (FK ke
  `oki_technicians`) — karena kolom `uploaded_by` lama cuma bisa nunjuk ke
  `oki_users` (staff), padahal sekarang teknisi juga bisa upload file.
  Salah satu dari `uploaded_by` / `uploaded_by_technician_id` selalu NULL,
  tergantung siapa yang upload (ditentukan otomatis di kode).
- Endpoint baru: `POST /api/orders/:id/pekerjaan` (khusus teknisi yang
  statusnya ASSIGNED di order tsb).

## 5. Clean URL — `.html` disembunyikan dari address bar

- `server.js`: `/dashboard`, `/orders`, `/order-detail`, dst sekarang
  diakses **tanpa** `.html`. Kalau ada yang buka `/dashboard.html`
  langsung (link lama, bookmark lama, dsb), otomatis di-redirect permanen
  (301) ke `/dashboard`.
- Semua link internal (`href`, `location.href`, dst) di seluruh halaman
  sudah diupdate mengikuti format baru ini.
- **Catatan jujur:** ini bikin URL lebih rapi dan sedikit lebih susah
  "ditebak strukturnya" secara sepintas, tapi ini **bukan** lapisan
  keamanan sungguhan — proteksi yang beneran nahan akses tetap di RBAC
  server-side (`requireAuth`/`requireRole`) yang sudah dibuat di round
  perbaikan sebelumnya. Siapapun yang tau/nebak path `/order-detail?id=5`
  tetap akan mental kalau rolenya gak berhak, itu yang bikin sistemnya
  aman — bukan karena `.html`-nya kesembunyi.

---

## CARA DEPLOY UPDATE INI

**`migration_v2.sql` sudah dihapus** — semua perubahan skema (V2 sampai V5)
sekarang digabung jadi satu di **`schema.sql`**, biar gak ada lagi risiko
beda versi antara migration & schema utama.

⚠️ **`schema.sql` sekarang mulai dengan `DROP TABLE` semua tabel `oki_*`
sebelum bikin ulang** — artinya menjalankan file ini **menghapus semua
data yang ada sekarang** (order, customer, teknisi, dst) dan mulai dari
seed data minimal lagi. Ini pilihan yang diminta biar gak ada mismatch
sama sekali antara skema & kode.

1. **Backup dulu kalau ada data yang mau dipertahankan:**
   ```
   mysqldump -h 192.168.100.111 -u sql_103_114_110_66 -p test > backup_sebelum_reset.sql
   ```
2. **Jalankan `schema.sql`** (drop + create ulang total):
   ```
   mysql -h 192.168.100.111 -u sql_103_114_110_66 -p test < schema.sql
   ```
3. `npm install` (gak ada dependency baru di round ini).
4. Restart server: `node server.js`.
5. Login ulang pakai akun seed baru (lihat bagian bawah `schema.sql`,
   password semuanya `password123`) — akun lama otomatis kehapus karena
   di-reset total.
6. Folder `uploads/bukti/` tetap dipakai (gak ada folder baru), tapi
   record file di database ikut ke-reset — file fisik lama di folder itu
   jadi orphan (gak ke-link dari database manapun), aman dihapus manual
   kalau mau beres-beres.
